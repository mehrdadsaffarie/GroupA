<?php
/* SVN FILE: $Id: _notInitalised.php 9 2010-12-17 13:21:39Z Chris $*/
/**
* RBAM home page "not initialised" partial view.
* es version
* 
* @copyright	Copyright &copy; 2010 PBM Web Development - All Rights Reserved
* @package		RBAM
* @since			V1.0.0
* @version		$Revision: 9 $
* @license		BSD License (see documentation)
*/
?>
<h2>RBAM No Inicializado</h2>
<p>El Role Base Access Manager módulo no se ha inicializado</p>
<p>Por favor, modifique la configuración RBAM módulo para especificar el origen de los datos intitialization, a continuación, ir a <?php echo Yii::app()->getRequest()->hostInfo.'/index.php?r=rbam'; ?></p> 
<p>Si no está seguro de lo que significa este mensaje, póngase en contacto con el administrador del sistema.</p>