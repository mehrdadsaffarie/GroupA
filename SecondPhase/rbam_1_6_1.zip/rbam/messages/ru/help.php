<?php
/* SVN FILE: $Id: help.php 19 2011-02-17 15:12:45Z Chris $*/
/**
* Message translation file.
* Help messages. (Help files use file translation)
* en-gb
* 
* @copyright	Copyright &copy; 2010 PBM Web Development - All Rights Reserved
* @package		RBAM
* @since			V1.0.0
* @version		$Revision: 19 $
* @license		BSD License (see documentation)
*/
return array(
	'Show help for this page'=>'Показать справку',
);
