
                                        ||--[]---[]---[]---[]---[]------[]--[]-||
                                        |					|
                                        |					|
                                        |  Copy Right By: 20 SCRIPT		|
                                        |					|
                                        |					|
                                        |  Web Site: WWW.20script.IR        	|
                                        |					|
                                        |  home coming : www.bistscript.ir	|
                                        |					|
                                        |  home page : www.20script.com	        |
                                        |					|
                                        |  Forum: http://forum.20script.ir/     |
                                        |					|
                                        |					|
                                        |  Shop: www.20script.ir/shop		|
                                        |					|
                                        |					|
                                        |  Yahoo ID: aka3_ir                    | 
                                        |                                       | 
                                        |  Email : aka3_ir@yahoo.com		|
                                        |	    		                |
                                        |					|
                                        |					|
                                        |					|
                                        ||--[]---[]---[]---[]---[]------[]--[]-||

