<?
session_start();
if(isset($_POST['submit'])){
	if($_SESSION['captcha'] == $_POST['captcha']){
		echo "Captcha Is Correct<br>";
	}else{
		echo "Captcha Isn't Correct<br>";
	}
}
?>

<img height="70" width="200" src="simplephpcaptcha.php"/>
<form action="" method="post">
	<input type="text" name="captcha" />
	<input type="submit" name="submit" />
</form>