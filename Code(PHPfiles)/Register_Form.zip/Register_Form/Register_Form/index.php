<a href="install.php">Install DB</a> / 
<a href="register.php">REGISTER</a> / 
<a href="login.php">Login</a> /
<a href="logout.php">Logout</a> / 
<a href="adminpage.php">Admin Page</a> / 
<a href="index.php">Index Page</a>
<hr>
