<?php
include('index.php');
include("db.php"); 
if(isset($_POST['username']) && isset($_POST['password'])){ 
// تایید ورود کاربر از طریق تابعی که در فایل دیتابیس نوشتیم    
	user_login($_POST['username'], $_POST['password']); 
} 
?>
<html>
  <form action="login.php" method="post">
     Username: <input name="username" type="text" />
     Password: <input type="password" name="password" />
	 <input type="submit" value="submit" />
  </form>
</html>