<?php 
include('index.php');
include "db.php";
if(!$_SESSION['username']){
// تغییر مسیر کاربر در صورتی که وارد یا لاگین نشده است
  header('location: ../login.php');
  exit();
}
?>
Hello ADMIN!
 Welcome to your page. ;)