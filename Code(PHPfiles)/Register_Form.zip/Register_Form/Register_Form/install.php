<?php
//نصب پایگاه داده

include('index.php');
// establish a connection to the database server
if(!mysql_connect('localhost', 'root', '')) {
    die("ERROR: Can't Connect To Database Server;" . mysql_error());
}
mysql_query("CREATE DATABASE myDB");
if(!mysql_select_db('myDB')) {
    mysql_close();
    die("ERROR: Can't Select Database;" . mysql_error());
}
mysql_set_charset('utf8');
$query = "
CREATE TABLE IF NOT EXISTS usersystem ( 
    userid INT(5) NOT NULL AUTO_INCREMENT , 
    username VARCHAR( 50 ) NOT NULL , 
    password VARCHAR( 32 ) NOT NULL , 
    email VARCHAR( 50 ) NOT NULL , 
    PRIMARY KEY ( userid )
)";
 
$result = mysql_query($query);
if (!$result) {
    echo'>> Can\'t Creat Users Table < < '.  mysql_error().'<br />';
} else {
    echo '[ Users Table Created Successfully ] <br />';
}
?>
<br><hr><a href="index.php">Index Page</a><br>