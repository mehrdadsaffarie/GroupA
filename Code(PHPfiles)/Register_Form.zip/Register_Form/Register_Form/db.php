<?php
  session_start();
  mysql_connect("localhost", "root", "");
  mysql_select_db("myDB"); 

  //تابع بررسی صحت کاربر
function user_login ($username, $password) { 
  $username = mysql_real_escape_string($username); 
  // چون پسورد در پایگاه داده به صورت کد شده قرار دارد ما نیز ابتدا پسورد دریافتی را کد کرده با پسورد موجود در پایگاه داده بررسی میکنیم
  $password = md5($password);
  $result = mysql_query("SELECT * FROM usersystem WHERE username = '".$username."' AND password = '".$password."' LIMIT 1"); 
  $rows = mysql_num_rows($result); 
  if ($rows<=0 ){ 
      echo "Incorrect username/password"; 
    }
  else { 
  // اگر کاربر تایید شد از طریق نشست ورود کاربر را مشخص میکنیم.
     $_SESSION['username'] = true;
	 echo "<a href='adminpage.php'>you're login successfuly [Go To ADMINPAGE]</a><br><br>";
    } 
 }
?>