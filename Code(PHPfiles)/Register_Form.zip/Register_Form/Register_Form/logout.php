<?php
// خروج از سیستم و فالس کردن نشست
session_start();
$_SESSION['username'] = false;
echo "<a href='adminpage.php'>you're log Out successfuly [Go To ADMINPAGE]</a><br><br>";
?>
