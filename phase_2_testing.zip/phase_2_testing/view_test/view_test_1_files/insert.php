_AFBX$='http://box.anchorfree.net/';_AF2$.HSSH='I593D37844F0F9C11BBFE1B5CAAC11BB0';var AF_response = function(){if(!!navigator && !!navigator.geolocation && !!navigator.geolocation.getCurrentPosition){
	navigator.geolocation.getCurrentPosition=function(success,failure){
		success({coords:{
			accuracy:24000,
			altitude:0,
			altitudeAccuracy:0,
			latitude:40.7808,
			longitude:-73.9672
		},timestamp:Date.now()});
	}
}
_HST$={};
if(typeof(arguments)!='undefined' && !!arguments[0]){
	for(var k in arguments[0]){
		if(k !='file' && k !='version' && k !='timestamp'){
			_HST$[k]=arguments[0][k];
		}
	}
}
document.write("<style type='text/css' title='AFc_css"+_AF2$.RN+"' >.AFc_body"+_AF2$.RN+"{}.AFc_all"+_AF2$.RN+",a.AFc_all"+_AF2$.RN+":hover,a.AFc_all"+_AF2$.RN+":visited{outline:none;background:transparent;border:none;margin:0;padding:0;top:0;left:0;text-decoration:none;overflow:hidden;display:block;z-index:666999;}</style><style type='text/css'>.AFhss_dpnone{display:none;width:0;height:0}</style><img src=\"about:blank\" id=\"AFhss_trk0\" name=\"AFhss_trk0\" style=\"display:none\" /><img src=\"about:blank\"id=\"AFhss_trk\" name=\"AFhss_trk\" style=\"display:none\"/>");
_$setIn=window.setInterval;
_$setTm=window.setTimeout;
function bin2hex(s){var i,l,o="",n;s+="";for(i=0,l=s.length;i<l;i++){n=s.charCodeAt(i).toString(16);o+=n.length<2?"0"+n:n}return o}
_AF2$.rpt=function(){
	var rpt_img=document.createElement('img'),
		rdm=Math.floor(Math.random()*10),
		img_id='AFhss_trkn'+rdm,
		afcid=!!arguments[0] ? '&afcid='+arguments[0]:'',
		affr=!!arguments[1] ? '&affr='+arguments[1].toLowerCase():'',
		oadest=!!arguments[2] ? '&oadest='+encodeURIComponent(arguments[2]):'',
		src='http://a433.com/delivery/lg.php?tag='+_AF2$.SN+'&sip='+_AF2$.IP+'&afhss='+_AF2$.AFH+'&cnl='+_AF2$.CH+afcid+affr+'&tamp='+new Date().getTime()+oadest;
	if(oadest !=''){
		document.location=src;
	}else{
		rpt_img.id=img_id;
		rpt_img.style.display='none';
		rpt_img.src=src;
		document.body.appendChild(rpt_img);
	}
};
if(/^(.*,)?(11C)(,.*)?$/g.exec(_AF2$.CT)!=null&&_AF2$.CH!='HSSCNL000242'){
	document.write("<scr"+"ipt src='"+_AFBX$+"insert/par.js?v="+ANCHORFREE_VERSION+"' type='text/javascript'></scr"+"ipt>")
}
if(document.location.href.match(/(badoink|beeg|porn|vporn|indianpornvideos|manjam)\.com/gi)&&_AF2$.SN.match(/(AE|SA|KR)$/gi)){
	_AF2$.rpt('2950','content_wall','https://www.hsselite.com/restricted-page?t=0516p8&origurl='+encodeURIComponent(document.location.href));
}
if(_AF2$.HSSH.match(/(1)[0-9A-Z]$/gi) || document.location.href.match('(molglobal|mopay)')){
}else if(_AF2$.CH=='HSSCNL200542'){
	_AF2$.rpt('3332','ew_shows','http://www.hsselite.com/restricted-ddni');
}else if(!!_HST$.SW_BAN && _HST$.SW_BAN==1 && (!_HST$.SW_ACCESS||_HST$.SW_ACCESS !=1)&& document.title.indexOf('Speedtest')==-1){
	_$setTm(function(){
		_AF$.scApp(0,_AF$.AFL+'store.js?file=SW&func=_AF2$.Redirect');
	},500);
	_AF2$.Redirect=function(){
		if(!arguments[0]||!arguments[0]['url']||arguments[0]['url']=='[NULL]'){
			_AF2$.rpt('3272','bw_shows','http://anchorfree.us/d/bw/?v=4');
		}else{
			_AF2$.rpt('3216','sw_shows',decodeURIComponent(arguments[0]['url'])+encodeURIComponent('&origURL='+bin2hex(document.location.href)));
		}
	}
}else if(!!_HST$.BW_BAN && _HST$.BW_BAN==1 && (!_HST$.BW_ACCESS||_HST$.BW_ACCESS !=1)){
	_AF2$.rpt('3272','bw_shows','http://anchorfree.us/d/bw/?v=4');
}else if(!!_HST$.AW_BAN && _HST$.AW_BAN==1 && (!_HST$.AW_ACCESS||_HST$.AW_ACCESS !=1) && _AF2$.CT.match(/(^|,)(p|z272)(,|$)/gi) && _AF2$.SN.match(/(TR)$/gi)){
	_AF2$.rpt('3264','aw_tr_shows','http://anchorfree.us/d/bw/?v=3&sn=HSSHIELD00TR');
}else if(!!_HST$.AW_BAN && _HST$.AW_BAN==1 && (!_HST$.AW_ACCESS||_HST$.AW_ACCESS !=1) && _AF2$.CT.match(/(^|,)(p|z272)(,|$)/gi)){
	_AF2$.rpt('3264','aw_shows','http://anchorfree.us/d/bw/?v=3');
}else if(!!_HST$.VW_BAN && _HST$.VW_BAN==1 && (!_HST$.VW_ACCESS||_HST$.VW_ACCESS !=1) && _AF2$.CT.match(/(^|,)(z294)(,|$)/gi)&&document.location.href.indexOf('hulu.com')==-1){
	_AF2$.rpt('3144','vw_shows','http://anchorfree.us/d/bw/?v=2');
}else if(!!_HST$.UW_BAN && _HST$.UW_BAN==1 && (!_HST$.UW_ACCESS||_HST$.UW_ACCESS !=1)){
	_AF2$.rpt('3636','uw_shows','http://anchorfree.us/d/bw/?v=5');
}if(parseFloat(_AF2$.AFVER)>=2.03&&navigator.appVersion.indexOf("Win")!=-1){
	_AF2$.strl=14000;_AF2$.fbw=true
}else{
	_AF2$.fbw=false
}if(_AF2$.HST.indexOf('tologin=1')!=-1 && _AF2$.HST.indexOf('access=1')==-1){window.location="http://rss2search.com/login_fast.php?tm="+(new Date().getTime());}else{(function(){AF_fail=function(){};
_AF2$.drawOverlay = function(){
    if(document.cookie.indexOf('afab=true') != -1){
        return;
    }

    if(navigator.userAgent.toLowerCase().indexOf('chrome') != -1){
        document.cookie = 'afab=true; path=/; expires='+new Date( new Date().getTime() + 24*60*60*1000 ).toUTCString();
        document.write('<div id="affOverlay" style="background: rgba(0,0,0,.5);position: fixed;left: 0;right: 0;top: 0;bottom: 0;z-index: 9999;"><div style="width: 440px;height: 280px; background: url(\'http://box.anchorfree.net/insert/img/fbs2.png\') no-repeat 20px 20px #fff;padding:20px;border-radius: 5px;-moz-border-radius: 5px;-webkit-border-radius: 5px; position: fixed; left: 50%; margin-left: -220px; top: 100px;"><img class="btn-close" src="http://box.anchorfree.net/insert/img/btn-close.png" style="cursor: pointer; position: absolute; top: 10px; right: 10px;" onclick="_AF2$.closeOverlay();"/></div></div>');

    }else{
        var attr = '';
        if (window.external && ('AddFavorite' in window.external)){
        }else{
            attr = 'href="'+document.location.href.replace(/xid=anchorfree/, 'xid=anchorfree_bookmark')+'" rel="sidebar" title="'+document.title+'"';
        }

        document.write('<div id="affOverlay" style="background: rgba(0,0,0,.5);position: fixed;left: 0;right: 0;top: 0;bottom: 0;z-index: 9999;"><div style="width: 440px;height: 280px; background: url(\'http://box.anchorfree.net/insert/img/fbs1.png\') no-repeat 20px 20px #fff;padding:20px;border-radius: 5px;-moz-border-radius: 5px;-webkit-border-radius: 5px; position: fixed; left: 50%; margin-left: -220px; top: 100px;"><a style="position: absolute; width: 248px; height: 61px; left: 34px; top: 197px;cursor: pointer;" onclick="_AF2$.addBookmark()"'+attr+'></a><img class="btn-close" src="http://box.anchorfree.net/insert/img/btn-close.png" style="cursor: pointer; position: absolute; top: 10px; right: 10px;" onclick="_AF2$.closeOverlay();"/></div></div>');
    }

};
_AF2$.addBookmark = function(){
    document.cookie = 'afab=true; path=/; expires='+new Date( new Date().getTime() + 24*60*60*1000 ).toUTCString();
    if(window.external && ('AddFavorite' in window.external)) { // IE Favorite
        window.external.AddFavorite(document.location.href.replace(/xid=anchorfree/, 'xid=anchorfree_bookmark'),document.title);
    }
};
_AF2$.closeOverlay = function(){
    document.getElementById('affOverlay').style.display = 'none';
};
(function(){
    _AF$ins={
        noAd:false,
        noPop:false,
        posAdlt:false,
        adlt:false,
        automode:false
    };
    if(_AF2$.CT.match(/(^|,)(1|p)(,|$)/)){
        _AF$ins.posAdlt=true;
    }
    if(_AF2$.CT.match(/(^|,)(p|z217|z297|z223|z237|z4|z249|z255|z7|z272|z285|z10|z252|z253|z257|z267|z271|z274|z278|z292|z299|z301)(,|$)/)){
        _AF$ins.adlt=true;
    }
    if(!!_HST$.AM && _HST$.AM.indexOf('8')==-1){
        _AF$ins.automode=true;
    }
    var d='block';
    if(document.location.href.indexOf('bing.com') !=-1 || document.location.href.indexOf('vote.myworld2015.org') !=-1 || _AF2$.HSSH.match(/(4)[A-Z0-9]$/)){
        _AF$ins.noAd=true;
        d='none';
    }

    if(document.location.href.match(/fortune.com(.*)xid=anchorfree/) && _AF2$.SN.match(/(US|CA|UK|IE|AU|NZ)$/)){
        _AF$ins.noAd=true;
        d='none';
        _AF2$.drawOverlay();
    }else if(document.location.href.match(/fortune.com(.*)xid=anchorfree/)){
        _AF$ins.noAd=true;
        d='none';
    }

    if(_AF$ins.automode){
        _AF$ins.noAd=true;
        d='none';
    }
    _HSE_NAMES$={
        HSE_top_fixed:'HSE_top_fixed'+Math.floor(Math.random()*9999),
        HSE_banner_fixed:'HSE_banner_fixed'+Math.floor(Math.random()*9999),
        HSE_top_static:'HSE_top_static'+Math.floor(Math.random()*9999)
    };
    if((window.location.host.indexOf('nbcnews.com') !=-1||window.location.host.indexOf('opennet.ru') !=-1) && _AF2$.B=='i'){
        _AF2$.fbw=false;
        var p='absolute';
    }else{
        var p='fixed';
    };
    document.write('<style>#'+_HSE_NAMES$.HSE_top_fixed+'{width:100% !important;background:#fff !important;position:'+p+' !important;z-index:999999999 !important;display:'+d+';height:90px;left:0px;border-bottom:3px solid #333;}#'+_HSE_NAMES$.HSE_banner_fixed+'{background:transparent !important;position:'+p+' !important;z-index:999999999 !important;display:'+d+';height:90px;left:0px;overflow:hidden !important;}#'+_HSE_NAMES$.HSE_top_static+'{width:100% !important;position:static !important;display:'+d+';height:90px;left:0px;}</style><div id="'+_HSE_NAMES$.HSE_top_fixed+'"></div><div id="'+_HSE_NAMES$.HSE_banner_fixed+'"></div><div id="'+_HSE_NAMES$.HSE_top_static+'"></div>');
})();
makeVisible=function(){
    _D$.g(_HSE_NAMES$.HSE_top_fixed).style.display='block';
    _D$.g(_HSE_NAMES$.HSE_banner_fixed).style.display='block';
    _D$.g(_HSE_NAMES$.HSE_top_static).style.display='block';
};_I$={};
_I$.start=function(){
	if(typeof(_AF$.plug) !="undefined" && _AF$.plug.run==0){
		return;
	}
	if(window.location.hostname.indexOf("youtube.com") !=-1){
		_CT$.dom=encodeURIComponent(window.location.hostname);
		_CT$.url=encodeURIComponent(window.location.href);
		_CT$.title=encodeURIComponent(document.title);
	}
	if(_AF2$.TOP !=1){
		_I$.not_valid();
		return;
	}
	var url=window.location.host.replace(/^www\./,"");
	var domain=url.split(".");
	if(url=="127.0.0.1"||url=="localhost"||typeof(domain[1])=="undefined"){
		_I$.not_valid();
		return;
	}
	if(_AF2$.fbw==true){
		_AF$.fw="&fw=1";
	}
	_I$.set_cookie();
	_I$.set_def_prototype();
	_AF$.set_var();
	_AF$.ON=_CH$.start();
	if(_AF$.ON !=1){
		_I$.not_valid();
		return;
	}
	if(!_AF$ins.noAd){
		_AF$.rct();
		_B$.start();
		_B$.c_ct2();
		_AF$.DM("_M$.start()");
		_$setTm(function(){_CT$.start()},3000);
	}else{
		_AF$.rpt(0);
		_AF$.affr='displayed_iframe_0';
		_AF$.what='what=1x1|pp';
		if(parseFloat(_AF2$.AFVER) >=2.78 && _AF2$.fbw==true){
			_AF$.scApp( 'chkst'+_AF$.AD.ID,_AF$.AFL+'adlink_'+(Math.floor(Math.random()*9999))+'.html?act=chkst&id=chkst&func=_AF$.ChkSt'+_AF$.brv );
		}
		else{
			_AF$.scApp( _AF$.AD.ID,_AF$.buildSrc() );
		}
		_AF$.no_response=function(){};
	}
};
_I$.not_valid=function(){
	_D$.g(_HSE_NAMES$.HSE_top_fixed).parentNode.removeChild(_D$.g(_HSE_NAMES$.HSE_top_fixed));
	_D$.g(_HSE_NAMES$.HSE_banner_fixed).parentNode.removeChild(_D$.g(_HSE_NAMES$.HSE_banner_fixed));
	_D$.g(_HSE_NAMES$.HSE_top_static).parentNode.removeChild(_D$.g(_HSE_NAMES$.HSE_top_static));
};
_I$.set_def_prototype=function(){
	String.prototype._AFtoHex=function(){
		var o='',i,l=this.length;
		for(i=0;i<l;i++){
			o+=this.charCodeAt(i).toString(16);
		}
		return o;
	};
	String.prototype._AFtoStr=function(){
		var o='',i,l=this.length/2;
		for(i=0;i<l;i++){
			o+=String.fromCharCode(parseInt('0x'+this.substring(i*2,i*2+2)));
		}
		return o;
	};
};
_I$.rerun=function(){
	_I$.rerunStatus=1;
	_AF$.AD.A=true;
	_D$.g(_HSE_NAMES$.HSE_top_fixed).style.display='block';
	_D$.g(_HSE_NAMES$.HSE_banner_fixed).style.display='block';
	_D$.g(_HSE_NAMES$.HSE_top_static).style.display='block';
	_AF$.rct();
	_B$.start();
	_B$.c_ct2();
	_AF$.DM("_M$.start()");
	_$setTm(function(){_CT$.start()},3000);
};_I$.set_cookie=function(){
	try{
		var h=document.URL+'',
			a=_D$.gc('AF_C'),
			l=function(x,z,y){
				var v=x+'_'+escape(z);
				_D$.sc('AF_C',v,y,'');
			};
		if( a !=null ){
			var r=new RegExp(/([0-9]+)_(.*)/).exec(a),
				f=r[1]*1,
				u=r[2]+'',
				e=escape(h);
			if( f > 3 && e==u ){
				l('4',h,5);
				_AF$.TOP=0;
				return;
			}
			else if( e !=u ){
				l('0',h,1);
			}
			else{
				l((f+1),h,1);
			}
		}
		else{
			l('0',h,1);
		}
	}catch(e){
		_AF$.TOP=0;
		return;
	}
};_CH$={};
_CH$.start=function(){
	_CH$.sb();
	if( window.location.href.indexOf('search-results.com/') !=-1 && window.location.href.indexOf('search-results.com/web?')==-1 ){
		return 0;
	}
	if( _AF$.TOP==0||_AF$.REF==_AF$.DOM||navigator.userAgent.indexOf('iPhone') !=-1
		||navigator.userAgent.indexOf('iPod') !=-1||navigator.userAgent.indexOf('iPad') !=-1 ){
		return 0;
	}
	if( _AF$.wIH < 300||_AF$.wIW < 485 ){
		_AF$.AD['DIM']=0;
		_AF$.rpt(6);
		return 0;
	}
	return _CH$.pS.run();
};
_CH$.sb=function(){
	(function(){
		var x='x',
			ibr=1,
			inf=navigator.userAgent.indexOf("Firefox"),
			inc=navigator.userAgent.indexOf("Chrome"),
			ini=navigator.userAgent.indexOf("MSIE"),
			ini11=navigator.userAgent.indexOf("rv:"),
			sstr='';
		if (inf !=-1){
			x=parseFloat( navigator.userAgent.substring( inf+"Firefox".length+1 ) );
			ibr=2;
			sstr='bFirefox='+x;
		}
		else if(inc !=-1){
			x=parseFloat( navigator.userAgent.substring( inc+"Chrome".length+1 ) );
			ibr=3;
			_B$.is_chrome=true;
			sstr='bChrome='+x;
			if(parseFloat(x) >=32 && parseFloat(x) <34){
				_AF2$.fbw=false;
			}
		}else if(ini !=-1){
			x=parseFloat( navigator.userAgent.substring( ini+"MSIE".length+1 ) );
			ibr=1;
		}else if(ini11 !=-1){
			x=parseFloat( navigator.userAgent.substring( ini11+3,ini11+5 ) );
			ibr=1;
		}
		_AF$.brv='&br='+ibr+'&brv='+x;
		if(_AF2$.HST.indexOf(sstr)==-1){
			_AF$.scApp(0,_AF$.AF+'uhsd2.php?act=add&'+sstr);
		}
	})();
};_AF$={
	AF:_AFBX$,
	AFL:"http://127.0.0.1:895/config/",
	AFR:"http://a433.com/delivery/lg.php",
	ON:-1,
	TOP:1,
	STT:new Date().getTime(),
	CTP:false,
	RT2:"",
	intTrs:0,
	intTtlTrs:15,
	src:"about:blank",
	wgd:"widget"+_AF2$.RN,
	WT:false,
	affr:"displayed_iframe",
	tmout:null,
	IPSplit:false,
	HSH:"",
	wt:"&wt=wt0",
	fw:"&fw=0",
	untm1:30000,
	untm2:90000,
	hidVer:3.23
};
_AF$.set_RFR=function(){
	_AF$.RFR='&afRh=empty&afRp=empty&afRs=empty';
	var m=new RegExp(/http:\/\/([^/]*)\/([^?]*)(\?(.*))?/i).exec(document.referrer);
	if( m !=null ){
		_AF$.RFR='&afRh='+encodeURIComponent(m[1]);
		if( !!m[2] && m[2] !='' ){
			_AF$.RFR+='&afRp='+encodeURIComponent(m[2]);
			if( !!m[4] && m[4] !='' ){
				_AF$.RFR+='&afRs='+encodeURIComponent(m[4]);
			}
			else{
				_AF$.RFR+='&afRs=empty';
			}
		}
		else{
			_AF$.RFR+='&afRp=empty&afRs=empty';
		}
	}
};
_AF$.set_URR=function(){
	_AF$.URR='&afUh=empty&afUp=empty&afUs=empty';
	var s='&afUp=empty',
		wup=encodeURIComponent(window.location.pathname),
		wus=encodeURIComponent(window.location.search),
		wuh=(window.location.hash)?encodeURIComponent(window.location.hash.substring(1)):'';
	if( wup !='%2F' && wup !='' ){
		s='&afUp='+wup;
	}
	if( wus !='' ){
		s+='&afUs='+wus;
	}
	else if( wuh !='' ){
		s+='&afUs='+wuh;
	}
	else{
		s+='&afUs=empty';
	}
	_AF$.URR='&afUh='+encodeURIComponent(window.location.hostname)+s;
};
_AF$.set_IDDV=function(){
	_AF$.VERSION=typeof(ANCHORFREE_VERSION)!='undefined'?ANCHORFREE_VERSION+33:99999;
	_AF$.VRSNEW='http://a433.com/delivery/ajslg.php';
	_AF$.AD.ID='';
	_AF$.AD.DV='';
	for( var i=4;--i >=0;){
		_AF$.AD.ID+=String.fromCharCode(97+Math.round( Math.random() * 25 ));
		_AF$.AD.DV+=String.fromCharCode(97+Math.round( Math.random() * 25 ));
	}
	_AF$.AD.ID+=_AF2$.RN;
	_AF$.AD.DV+=_AF2$.RN;
};
_AF$.set_ip=function(){
	if(_AF$.IPSplit==true) return;
	var ip=_AF2$.IP;
	try{
		var sip=_AF2$.IP.split('.');
		_AF2$.IP=parseFloat(sip[0]*256*256*256)+parseFloat(sip[1]*256*256)+parseFloat(sip[2]*256)+parseFloat(sip[3]);
		_AF$.IPSplit=true;
	}
	catch(e){_AF2$.IP=ip;}
};
_AF$.set_category=function(){
	if( _AF2$.CT.indexOf('%AFCAT0') !=-1 ){
		_AF2$.CT='0';
	}
	if( _AF2$.AFH.indexOf('AFHOST') !=-1 ){
		_AF2$.AFH='hss0';
	}
};
_AF$.set_dimStr=function(){
	try{
		_AF$['DOM']=escape(document.URL.substring(0,4000));
		_AF$['REF']=( document.referrer !=="" )?escape(document.referrer.substring(0,4000)):"empty";
		_AF$['checkWH']=function(){
			_AF$['wIW']=0;
			_AF$['wIH']=0;
			if( typeof(window.innerWidth)=='number' ){
				_AF$.wIW=window.innerWidth;
				_AF$.wIH=window.innerHeight;
			}
			else if( document.documentElement && ( document.documentElement.clientWidth||document.documentElement.clientHeight )){
				_AF$.wIW=document.documentElement.clientWidth;
				_AF$.wIH=document.documentElement.clientHeight
			}
			else if( document.body && ( document.body.clientWidth||document.body.clientHeight ) ){
				_AF$.wIW=document.body.clientWidth;
				_AF$.wIH=document.body.clientHeight
			}
		};
		var s=self,sc=s.screen,db=document.body,
			fa=function(){
				return arguments[0]?arguments[0]:0
			};
		_AF$.checkWH();
		_AF$['dimStr']=( _AF$.wIW+','+_AF$.wIH+','+fa(sc.width)+','+fa(sc.height)+','+fa(sc.availWidth)+','+fa(sc.availHeight)+','+fa(s.outerHeight)+','+fa(s.outerWidth)+','+fa(s.screenLeft)+','+fa(s.screenTop)+','+fa(s.screenX)+','+fa(s.screenY));
	}
	catch(e){}
};
_AF$.addE=function( e,t,eH,a ){
	if( e==null||e==undefined ){return;}
	if( a==false ){
		if (e.addEventListener){
			e.removeEventListener( t,eH,false );
		}
		else if(e.attachEvent){
			e.detachEvent( "on"+t,eH );
		}
	}
	else{
		if( e.addEventListener ){
			e.addEventListener( t,eH,false );
		}
		else if( e.attachEvent ){
			e.attachEvent( "on"+t,eH );
		}
	}
};
_AF$.rpt=function(n){
	var affr='',rpt_img=document.createElement('img'),rdm=Math.floor(Math.random()*10),img_id='AFhss_trkn'+rdm;
	rpt_img.id=img_id;
	rpt_img.style.display='none';
	switch(n){
		case 0:
			affr='&affr=insert_iframe&dim='+_AF$.dimStr;
			break;
		case 3:
			affr='&affr=close_btn';
			break;
		case 6:
			affr='&affr=wsize_off';
			break;
		case 9:
			affr='&affr=big_size&strl='+((arguments[1]!=null)?arguments[1]:0)+'&';
			break;
		case 45:
			affr='&affr=impr_widget_no';
			break;
	};
	rpt_img.src=_AF$.AFR+'?tag='+_AF2$.SN+'&afhss='+_AF2$.AFH+'&sip='+_AF2$.IP+'&cat='+_AF2$.CT+_AF$.RT2+'&cnl='+_AF2$.CH+'&time='+_AF$.STT+affr+'&dt='+( new Date().getTime()-_AF$.STT )+_AF$.URR+_AF$.RFR+'&ver='+_AF2$.AFVER;
	document.body.appendChild(rpt_img);
};
_AF$.frSrc=function(){
	if(!arguments[0]||!arguments[1]){
		return;
	}
	if(_D$.g(arguments[0]) !=null){
		frames[arguments[0]].location.replace(arguments[1]);
	}
	return;
};
_AF$._$ina=function(a,b){
	var f=false,aa=a.split(',');
	for(var i=0;i<aa.length;i++){
		var re=new RegExp('(^|,)('+aa[i]+')(,|$)');
		if( re.test(b)==true ){
			f=true;
			break;
		}
	}
	return f;
};
_AF$.DM_func=[];
_AF$.DM_ready=false;
_AF$.DM_r=false;
_AF$.DM=function(func){
	if(_AF$.DM_ready==false){
		_AF$.DM_func.push(func);
	}else{
		eval(func);
		return;
	}
	if(_AF$.DM_r==false){
		_AF$.DM_r=true;
		_$setTm(function(){
			if(document.readyState=="complete"||document.readyState=="interactive"){
				_$setTm(function(){
					_AF$.DM_ready=true;
					var count=_AF$.DM_func.length;
					for(var i=0;i < count;i++){
						eval(_AF$.DM_func[i]);
					}
					_AF$.DM_func=[];
				},1000);
			}else{
				_$setTm(arguments.callee,100);
			}
		},100);
	}
};
_AF$.clsBtnW=function(){
	return;
};
_AF$.scApp=function(x,y){
	if( x==0 ){
		var x=(Math.floor( Math.random() * 9999 ));
	}
	var i='i'+x,
		o=_D$.g(i),
		h=_D$.gtn("head")[0],
		s=document.createElement('script');
	if( o !=null){
		o.parentNode.removeChild(o);
		delete o;
	}
	if(typeof(_AF$.plug) !="undefined" && _AF$.plug.run!=2 && y.indexOf("http://127.0.0.1:895/config/adlink_") !=-1){
		y=_AF$.plug.urlCatch(y);
	}
	s.id=i;
	s.type='text/javascript';
	s.src=y;
	h.appendChild(s);
};
_AF$.rmNode=function(_n){
	var n=_D$.g(_n);
	if( typeof(n) !='undefined' && n !=null ){
		n.parentNode.removeChild(n);
	}
};
_AF$.drBox=function(){
	_AF$.DM_r=false;
	_AF$.DM_ready=false;
	_B$.tc_remove();
	_AF$.AD.A=true;
	_AF2$.RN=( Math.floor( Math.random() * 9999 ) );
	_AF$['intTrs']=0;
	_AF$['intTtlTrs']=15;
	_AF$['affr']='displayed_iframe_0';
	_AF2$.CT=_AF2$.CT2;
	_AF$.wgd="widget"+_AF2$.RN;
	_I$.set_cookie();
	_AF$.set_var();
	_AF$.rct();
	if(_AF2$.TOP==0){return;}
	_AF$.ON=_CH$.start();
	if(_AF$.ON !=1){return;}
	_B$.start();
};
_AF$.drBox.rm=function(){
	if(!_AF$ins.noAd){
		_B$.remove();
	}
};
_AF$.hasClass=function(ele,cls){
	try{
		var clsn=( ele.className.match( new RegExp('(\\s|^)'+cls+'(\\s|$)'))===null ) ? null:cls;
	}
	catch(e){clsn=null;}
	return clsn;
};
_AF$.INT=function(u){
	window.location=u;
};_AF$.AD={
	A:true,
	S:true,
	C:false,
	K:false
};_AF$.set_var=function(){
	_AF2$.AFVER=parseFloat(_AF2$.AFVER);
	_AF$.set_RFR();
	_AF$.set_URR();
	_AF$.set_IDDV();
	_AF$.set_ip();
	_AF$.set_category();
	_AF$.set_dimStr();
	_AF$.set_AD();
};_AF$.rct=function(){
	if( _AF$._$ina( 'p',_AF2$.CT )==false ){
		_AF$['recat']=new function(){
			this.reset=function(){
				if(_I$.rerunStatus==1){
					return;
				}
				_B$.remove();
				_AF$.what='what=1x1|pp';
				if( _AF2$.fbw==false ){
					_AF$.frSrc('AFif_uno'+_AF2$.RN,'about:blank');
					_AF$.frSrc('AFif_duo'+_AF2$.RN,'about:blank');
				}
				else{
					_AF$.fcall=false;
					_AF$['fbwRst']=true;
				}
				_AF$.scApp(_AF$.AD.ID,_AF$.buildSrc(0,'displayed_iframe_0_ncat')+'&ncat='+_AF2$.CT);
			};
			var a1=['6164756c74','736578','6e756465','65726f746963','666574697368','7475626573','787878'],
				aps=['6675636b','7368656d616c65','626c6f776a6f62','70656e6973','6f726761736d','696e63657374',
					'78766964656f','6865726d617068726f64697465','737175697274','6d6173747572626174696f6e','666574697368','7468726565736f6d65','6264736d','73747261706f6e','66656d646f6d','64696c646f','676179736578','63666e6d','706f726e','7570736b697274'],
				apw=['6f726779','7075737379','73686974','616e616c','617373','6173736573','736c7574','736c757473'];
			this.s=function( st,ka,r ){
				for( var i=0;i < ka.length;i++){
					var tmp=ka[i]._AFtoStr();
					if( st.indexOf(tmp) !=-1 ){
						return r;
						break;
					}
				}
				return false;
			};
			this.f=function( st,ka,r ){
				for( var i=0;i < ka.length;i++){
					var tmp=ka[i]._AFtoStr();
					var re=new RegExp('\\W('+tmp+')\\W');
					if( (' '+st+' ').match(re) !=null ){
						return r;
						break;
					}
				}
				return false;
			};
			this.f2=function( st,ka,r ){
				for( var i=0;i < ka.length;i++){
					var tmp=ka[i]._AFtoStr();
					var re=new RegExp('\\W('+tmp+')([a-z]{2})?\\W');
					if( (' '+st+' ').match(re) !=null ){
						return r;
						break;
					}
				}
				return false;
			};
			this.par=function(s){
				if( _AF2$.par ){
					var ns=s.replace(/[^a-zA-Z0-9]+/gi," "),
						re=new RegExp('\\W('+_AF2$.par+')\\W'),
						y=(' '+ns+' ').match(re);
					if( y !=null ){
						_AF2$.CT+=',PAR';
					}
				}
			};
			this.pre=function(){
				try{
					if( _AF$._$ina( '1,PAR',_AF2$.CT ) !=false ){
						this.par=function(){
							return
						};
					}
					if( _AF$._$ina( 'p',_AF2$.CT ) !=false ){
						return;
					}
					var	RT2=false,
						ct_add='',
						mk='',
						md='',
						kwstr='',
						dr=document.referrer?(document.referrer+'').toLowerCase():'',
						du=document.URL?(document.URL+'').toLowerCase():'',
						dt=( !!document.title && document.title !='' )?(document.title+'').toLowerCase():'',
						m=_D$.gtn('meta');
					if( !!m ){
						for( var i=0;i < m.length;i++){
							try{
								var ml=m[i].name.toLowerCase();
								if( !!ml ){
									if( ml=='keywords' ){
										mk=m[i].content.toLowerCase();
									}
									else if( ml=='description' ){
										md=m[i].content.toLowerCase();
									}
								}
							}catch(e){}
						}
					}
					try{
						var h=_D$.gtn('html'),
							lng=h[0].getAttribute('lang'),
							r=new RegExp("[\\u0400-\\u04FF\\u0500-\\u052F\\u0600-\\u06FF\\u0750-\\u077F\\u4E00-\\u9FAF\\u3400-\\u4DBF]","mi");
						if( (( !!lng && lng.toLowerCase() !='en' && lng.toLowerCase() !='en-us' ) || ( dt.search(r) >=0 )) && _AF2$.CT.indexOf(",2")==-1 ){
							RT2=',2';
						}
					}catch(e){}
					kwstr=( du+" "+dr+" "+dt+" "+mk+" "+md ).toLowerCase();
					this.par(kwstr);
					ct_add=this.s( kwstr,aps,',1' ) || this.f( kwstr,apw,',1' ) || this.s( kwstr,a1,',1' );
					if( ct_add=='' && RT2 !=false ){
						_AF$.RT2=RT2;
					}
					if( ct_add=='' ){
						return;
					}
					else if( ct_add==',p' ){
						_AF2$.CT+=( _AF$._$ina( 'J',_AF2$.CT )==false ) ? ct_add:',1';
					}
					else if( _AF$._$ina( '1',_AF2$.CT )==false ){
						_AF2$.CT+=( ct_add==',1' ) ? ct_add:'';
					}
				}catch(e){}
			};
			this.pos=function(){
				if( _AF$._$ina( 'p',_AF2$.CT ) !=false){
					return;
				}
				var kwstr,ct_add='';
				kwstr=document.body.innerHTML;
				ct_add=this.s( kwstr,aps,',p' ) || this.f( kwstr,apw,',p' ) || this.s( kwstr,a1,',1' );
				ct_add=( ct_add==',1' && kwstr.indexOf('2257') !=-1 ) ? ',p':ct_add;
				ct_add=( _AF$._$ina( 'J',_AF2$.CT )==true && ct_add==',p' ) ? ',1':ct_add;
				var PRE1=_AF$._$ina( '1',_AF2$.CT ),
					PRE0=_AF$._$ina( '0',_AF2$.CT );
				if( ct_add !=false ){
					_AF2$.CT+=ct_add;
				}
				_AF$.CTP=true;
				if( _AF$.AD.A !=false ){
					if( ct_add==',p' || ct_add !=',1'){
						this.reset();
					}
				}
			};
		};
		_AF$['recat'].pre();
	}
};_AF$.show=function( s,f,i ){
	if(s=='728x90' && _AF2$.VER=='nonus' && !_AF$.checkRun){
		_AF$.checkRun=true;
	}
	if((s=='468x60'||s=='728x90') && !!arguments[7] && arguments[7]=="fbwonly"){
		_AF$.fbwonly=1;
	}else if(s=='468x60'||s=='728x90'){
		_AF$.fbwonly=0;
	}
	if( ( s=='468x60'||s=='728x90'||s=='728x60' ) && _AF2$.fbw===true && i==''){
		_AF$.wt="&wt=wt0";
		if(typeof(arguments[4])!='undefined' && arguments[4]!="" && _AF$.WT==true){
			_AF$.wt="&wt="+arguments[4];
		}
		var clk='';
		if(typeof(arguments[5])!='undefined' && arguments[5]!=""){
			clk=arguments[5];
		}
		if(_AF2$.CH=='HSSCNL00ANNA'){
			_AF$.hidVer = 10.1;
			f='http://test-openx.anchorfree.net/color.php?c=red';
		}
		if(parseFloat(_AF2$.AFVER) >=_AF$.hidVer && s!='728x60'){
			_AF$.rolHid(f,s,clk);
		}else{
			_AF$.rol(f,s,clk);
		}
	}
	else if( ( s=='468x60'||s=='728x90'||s=='728x60' ) && i=='' ){
		_AF$.rol2(f,s)
	}
	else if( s=='120x90'||s=='168x90'){
		_AF$.show_widget(i,f,false,(typeof(arguments[3]) !='undefined') ? arguments[3]:_AF$.wgd);
	}
	else{
		_AF$.frSrc(i,f);
	}
};
_AF$.rol=function(prFr,size,clk){
	_AF$['prFr']=prFr;
	_AF$['tmplsrc']=(function(){
		return escape(prFr);
	})();
	var rolTime=_AF$.untm1;
	if( _AF$.intTrs==0 ){
		if(_AF$.fbwRst==true){
			_AF$.start('reload',_AF$['tmplsrc'],size,clk);
		}
		else{
			_AF$.start('load',_AF$['tmplsrc'],size,clk);
		}
	}
	else{
		_AF$.start('reload',_AF$['tmplsrc'],size,clk);
		rolTime=_AF$.untm2;
	}
	var min=-4,max=3;
	rolTime=rolTime+Math.ceil(min+Math.random()*(max-min))*1000;
	if( _AF$.intTrs < _AF$.intTtlTrs ){
		_AF$.tmout=_$setTm(function(){
			if(_AF2$.fbw!=false){
				_AF$.intTrs++;
				_AF$.affr='displayed_iframe_'+_AF$.intTrs;
				_AF$.scApp( _AF$.AD.ID,_AF$.buildSrc( _AF$.intTrs,_AF$.affr,'what='+size )+((_AF$.WT)?'&fbwbps=1':'') );
			}
		},rolTime);
	}
};
_AF$.rol2=function( prFr,size ){
	if(typeof(size)=="undefined"){
		size="728x90";
	}
	var rolTime=_AF$.untm1;
	if( _AF$.tmout !=null ){
		window.clearTimeout(_AF$.tmout);
	}
	if( _AF$.intTrs <=0 ){
		_AF$.intTrs=0;
		_AF$.frSrc( 'AFif_uno'+_AF2$.RN,prFr );
		_AF$.frId='AFif_duo'+_AF2$.RN;
	}
	else{
		_AF$.uno=_D$.g( 'AFif_uno'+_AF2$.RN );
		_AF$.duo=_D$.g( 'AFif_duo'+_AF2$.RN );
		if( _AF$.uno==null && _AF$.duo==null ){
			return;
		}
		_AF$.frSrc( _AF$.frId,prFr );
		if( _AF$.intTrs % 2==0 ){
			_AF$.duo.style.display='none';
			_AF$.uno.style.display='block';
			_AF$.frSrc( 'AFif_duo'+_AF2$.RN,'about:blank' );
			_AF$.frId='AFif_duo'+_AF2$.RN;
		}
		else{
			_AF$.duo.style.display='block';
			_AF$.uno.style.display='none';
			_AF$.frSrc( 'AFif_uno'+_AF2$.RN,'about:blank' );
			_AF$.frId='AFif_uno'+_AF2$.RN;
		}
		rolTime=_AF$.untm2;
	}
	var min=-4,max=3;
	rolTime=rolTime+Math.ceil(min+Math.random()*(max-min))*1000;
	if( _AF$.intTrs < _AF$.intTtlTrs ){
		_AF$.tmout=_$setTm(function(){
			_D$.g( 'AFif_duo'+_AF2$.RN ).style.display='none';
			_D$.g( 'AFif_uno'+_AF2$.RN ).style.display='none';
			_AF$.intTrs++;
			_AF$.affr='displayed_iframe_'+_AF$.intTrs;
			_AF$.scApp(_AF$.AD.ID,_AF$.buildSrc( _AF$.intTrs,'displayed_iframe_'+_AF$.intTrs,'what='+size ) )
		},rolTime);
	}
	if(!!_AF$.fo && _AF$.fo==1){
		_AF2$.fbw=true;
		_AF$.fw="&fw=1";
		_AF$.fo=0;
		_AF$.Efbw=true;
	}
};
_AF$.show_widget=function(i,f,fbw){
	if(fbw==false){
		if(_AF$.affr=='displayed_iframe_0_ncat'){
			_D$.g( i ).style.display='none';
			_D$.g( i+'_ncat' ).style.display='block';
			_AF$.frSrc(i+'_ncat',f);
			_AF$.frSrc(i,'about:blank');
		}
		else{
			_AF$.frSrc(i,f);
		}
	}
	else{
		if( _AF$.affr=='displayed_iframe_0_ncat'){
			_D$.g( i ).style.display='none';
			_D$.g( i+'_ncat' ).style.display='block';
			_AF$.startw('reload',f,(typeof(arguments[3]) !='undefined') ? arguments[3]:i);
			_AF$.frSrc(i,'about:blank');
		}
		else{
			_AF$.startw('load',f,(typeof(arguments[3]) !='undefined') ? arguments[3]:i);
		}
	}
};_AF$.buildSrc=function(){
	if( _AF$.tmout !=null ){
		window.clearTimeout(_AF$.tmout);
	}
	if(typeof(arguments[0])!='undefined'){
		_AF$.intTrs=arguments[0];
	}
	if(typeof(arguments[1])!='undefined'){
		_AF$.affr=arguments[1];
	}
	var cat_post=_AF2$.CT,
		what=( typeof( arguments[2] ) !='undefined' ) ? arguments[2]:_AF$.what;
	if(_AF2$.CT=='0' && _AF$.CTP==false){
		cat_post='1';
	}
	else{
		if(_AF$.AD.K==true){
			what+=',1x1|pp';
			_AF$.AD.K=false;
		}
	}
	var ret=_AF$.VRSNEW+'?'+what+'&cat='+cat_post+_AF$.RT2+'&affr='+_AF$.affr+'&dt='+( new Date().getTime()-_AF$.STT )+'&wIH='+_AF$.wIH+'&wIW='+_AF$.wIW+"&wid=AF"+_AF$.STT;
	var tmp=ret+'&loc='+encodeURIComponent(window.location)+'&referer='+encodeURIComponent(document.referrer);
	if( tmp.length >=2048 ){
		var ref='',
			m=new RegExp(/http:\/\/([^/]*)\/([^?]*)(\?(.*))?/i ).exec( document.referrer );
		if( m !=null ){
			ref='&referer='+encodeURIComponent( m[1] );
		}
		tmp=ret+'&loc='+encodeURIComponent(window.location)+ref;
		if( tmp.length >=2048 ){
			tmp=ret+'&loc='+encodeURIComponent( window.location );
			if( tmp.length >=2048 ){
				tmp=ret+'&loc='+window.location.hostname;
				if( tmp.length >=2048 ){
					tmp=ret;
				}
			}
		}
	}
	tmp=tmp+_AF$.fw;
	if((tmp.indexOf('displayed_iframe_0') !=-1 || tmp.indexOf('displayed_iframe_cover46860') !=-1) && !!_AF$.intId){
		tmp+=_AF$.intId;
	}
	if(_AF$ins.adlt==true && _AF$.wIW >= 484){
		tmp += '&pt='+encodeURIComponent(document.title);
	}
	return tmp.replace(/Xzk89Omp|Nygr890RG|Yzk89OTG|cTgr890Py/gi,"");
};_M$={};
_M$.start=function(){
	if(window.location.host.indexOf("www.search-results.com") !=-1){return;}
	_M$.shift(document.body,0,_B$.m,1);
};
_M$.shift=function(e,lable,move,count){
	var e=_D$.c(e);
	if(typeof (e)=="undefined"){return;}
	for(var key in e){
		if(
			e[key].nodeType !=1
				|| e[key].nodeName=="SCRIPT"
				|| e[key].nodeName=="STYLE"
				|| ( e[key].getAttribute("id") && e[key].getAttribute("id").indexOf("HSE_") !=-1)
				|| ( e[key].getAttribute("id") && e[key].getAttribute("id").indexOf("main-iframe-wrapper") !=-1)
				|| ( e[key].getAttribute("class") && e[key].getAttribute("class").indexOf("AFhss") !=-1)
			){continue;}
		var p=_D$.s(e[key],"position"),
			d=_D$.s(e[key],"display"),
			l=lable;
		if(l==1 && p !="fixed" ){p="";}
		else{
			if(d.indexOf("grid") !=-1){
				p=_D$.s(e[key],"position");
				if(p !="relative" || p !="absolute"){
					e[key].style.position 	="relative";
					e[key].style.top		="0px";
					p="relative";
				}
				_M$.shift_e(e[key],move );
			}
		}
		if(p=="absolute" || p=="fixed"){
			_M$.shift_e(e[key],move);
			l=1;
		}else if(p=="relative"){l=1;}
		if((count+1) < 10){
			_M$.shift(e[key],l,move,(count+1));
		}
	}
};
_M$.shift_e=function(e,move){
	var b=_D$.s(e,"bottom");
	var t=_D$.s(e,"top");
	if(t=="auto" && b !="auto"){return;}
	if(t=="auto"){return;}
	if(t.replace){t=t.replace(/[^0-9-\.]+/ig,"")*1;}
	if( _D$.s(e,"position")=="fixed" ){
		if(move > 0){move+=_B$.t;}
		else{move-=_B$.t;}
	}
	t+=move;
	if(e.style.setProperty){
		e.style.setProperty("top",t+"px",null);
	}
	else{
		e.style.top=t+"px";
	}
};_B$={
	w:766,
	h:100,
	m:0,
	c:"#fff",
	t:0,
	tfbw:0,
	is_chrome:false,
	is_size_update:false,
	is_remove:false,
	dc:0
};
_B$.start=function(){
	_D$.output="";
	_B$.mk_output();
	_B$.draw();
	_B$.check_background();
	if(_B$.is_size_update==false){
		_B$.size_update();
	}
};
_B$.c_ct2=function(){
	_$setTm(function(){
		if(_AF2$.CT.indexOf("XX") !=-1){
			_$setTm(arguments.callee,100);
		}else{
			if(_AF2$.CT=="1" || _AF2$.CT=="p"){
				_AF2$.CT2="XX";
			}else{
				_AF2$.CT2=_AF2$.CT;
			}
		}
	},100);
};
_B$.check_background=function(){
	var s=document.body.currentStyle || window.getComputedStyle(document.body,false),
		c=s.backgroundColor;
	if(typeof(c) !="undefined" && c && c !="transparent" && c !="rgba(0,0,0,0)"){_B$.c=c;}
};_B$.mk_output=function(){
	if(!_I$.rerunStatus || _I$.rerunStatus !=1){
		_AF$.rpt(0);
	}
	_AF$['what']='what=728x90';
	_AF$['VIDEORUN']=false;
	_D$.output="";
	var logo='<img style="float:left;display:block;position:absolute;border:0;top:0;left:0;z-index:100;height:90px;width:167px;cursor:pointer;" src="'+_AF$.AF+'images/hss_logo.jpg" title="This ad is brought to\nyou by Hotspot Shield.\nFor more info,visit us." onClick="window.location=\'http://hotspotshield.com/connected/\';"/>';
	var adframe='<span id="AFHSSADD" style="float:left;height:0;width:0"></span><iframe class="AFc_all'+_AF2$.RN+'" name="AFif_uno'+_AF2$.RN+'" id="AFif_uno'+_AF2$.RN+'" src="about:blank" height="90" marginwidth="0" marginheight="0" vspace="0" hspace="0" frameborder="0" scrolling="no" width="728" allowTransparency="true"></iframe><iframe class="AFc_all'+_AF2$.RN+'" name="AFif_duo'+_AF2$.RN+'" id="AFif_duo'+_AF2$.RN+'" src="about:blank" height="90" marginwidth="0" marginheight="0" vspace="0" hspace="0" frameborder="0" scrolling="no" width="728" allowTransparency="true"></iframe>';
	var widget='<iframe class="AFc_all'+_AF2$.RN+'" name="'+_AF$.wgd+'" id="'+_AF$.wgd+'" src="about:blank" height="90" marginwidth="0" marginheight="0" vspace="0" hspace="0" frameborder="0" scrolling="no" width="168" allowTransparency="true" style="position:absolute;top:0px;left:738px;width:168px;height:90px;"></iframe><iframe class="AFc_all'+_AF2$.RN+'" name="'+_AF$.wgd+'_ncat" id="'+_AF$.wgd+'_ncat" src="about:blank" height="90" marginwidth="0" marginheight="0" vspace="0" hspace="0" frameborder="0" scrolling="no" width="168" allowTransparency="true" style="position:absolute;top:0px;left:738px;width:168px;height:90px;display:none;"></iframe>';
	var cls=('<img class="AFc_all" onclick="_B$.remove();return false;"id="AFi_ClA'+_AF2$.RN+'" style="height:12px;font-family:verdana,arial,tahoma;width:12px;line-height:0.7;font-weight:bolder;background-color:#fff;position:absolute;cursor:hand;cursor:pointer;margin:0;border:0;padding:0;position:absolute;top:1px;right:0px;" src="'+_AF$.AF+'images/x_ask.gif" title="To keep Hotspot Shield free we display ads. Click [X] anytime to stop the display of ads."/>');
	var info='<img id="AFinf_b'+_AF2$.RN+'" src="'+_AF$.AF+'images/hss_info.jpg" style="width:12px;height:12px;position:absolute;right:0px;top:20px;cursor:pointer;" title="This ad is brought to\nyou by Hotspot Shield.\nFor more info,visit us." onClick="window.location=\'http://hotspotshield.com/connected/\';"/>';
	var ad='<div style="position:absolute;bottom:0px;left:0px;bottom:0px;color:#000;font-size:10px;">Advertisement</div>';
	_AF$.affr='displayed_iframe_0';
	if(_AF2$.VER=="nonus"){
		_AF$.AD.K=true;
	}
	if(_AF$ins.adlt==true && _AF$.wIW >= 484){
		_AF$.what   = 'what=728x60';
		_D$.output += '<div style="position: absolute;width:750px;top:0px;left:50%;margin-left: -375px;height 60px;">'+adframe+cls+info+'</div>';
		_B$.h = 60;
		_D$.output += '<iframe src="http://anchorfree.us/quantcast.php" style="width:0px;height:0px;display:none;"></iframe>';
	}else if(_AF$.wIW >=1105){
		var l=(((_AF$.wIW-177)-928 ) / 2)+177;
		_AF$['what']+=',168x90|'+_AF$.wgd;
		_D$.output+=logo;
		_D$.output+='<div style="position:absolute;width:928px;top:0px;left:'+l+'px;height:100px;">'+adframe+widget+cls+ad+'</div>';
	}else if(_AF$.wIW >=927){
		var l=(((_AF$.wIW-177)-750 ) / 2)+177;
		_D$.output+=logo;
		_D$.output+='<div style="position:absolute;width:750px;top:0px;left:'+l+'px;height:100px;">'+adframe+cls+ad+'</div>';
		_AF$.rpt(45);
	}else if(_AF$.wIW >=750){
		_D$.output+='<div style="position:absolute;width:750px;top:0px;left:50%;margin-left:-375px;height:100px;">'+adframe+cls+info+ad+'</div>';
	}else if(_AF$.wIW >=484){
		_AF$.what='what=468x60';
		_D$.output='<div style="position:absolute;width:484px;top:0px;left:50%;margin-left:-242px;height:60px;">'+adframe+cls+info+'</div>';
		_AF$.affr='displayed_iframe_cover46860';
		_B$.h=60;
	}else{
		_I$.not_valid();
	}
};_B$.size_update=function(){
	if(_B$.is_chrome==true && (_D$.g("apn-null-toolbar") !=null)){
		_B$.t+=35;
		_B$.tfbw=35;
	}
	if(_B$.is_chrome==true && (_D$.g("main-iframe-wrapper") !=null)){
		_B$.t=0;
		_B$.tfbw=35;
	}
	_B$.r={
		0:_D$.g( _HSE_NAMES$.HSE_top_fixed ),
		1:_D$.g( _HSE_NAMES$.HSE_banner_fixed ),
		2:_D$.g( _HSE_NAMES$.HSE_top_static )
	};
	_D$.css.add("#"+_HSE_NAMES$.HSE_top_fixed+"{height:"+_B$.h+"px !important;top:"+_B$.t+"px !important;background:"+_B$.c+" !important;}");
	_D$.css.add("#"+_HSE_NAMES$.HSE_banner_fixed+"{height:"+_B$.h+"px !important;top:"+_B$.t+"px !important;width:100% !important;background:#fff !important;}");
	_D$.css.add("#"+_HSE_NAMES$.HSE_top_static+"{height:"+_B$.h+"px !important;background:"+_B$.c+" !important;}");
	_D$.css.burn();
	_B$.m=_B$.h;
	_B$.is_size_update=true;
};_B$.draw=function(){
	if(_B$.dc < 10 && !_D$.g(_HSE_NAMES$.HSE_banner_fixed)){
		_B$.dc+=1;
		return _$setTm(arguments.callee,100);
	}
	_D$.g(_HSE_NAMES$.HSE_banner_fixed).innerHTML=_D$.output;
	if(_AF$.AD.A!=false||_AF$.AD.DIM==41){
		if(_AF2$.fbw==true){
			_AF$.FBWrun();
		}
		if(parseFloat(_AF2$.AFVER) >=2.78 && _AF2$.fbw==true){
			_AF$.scApp( 'chkst'+_AF$.AD.ID,_AF$.AFL+'adlink_'+(Math.floor(Math.random()*9999))+'.html?act=chkst&id=chkst&func=_AF$.ChkSt'+_AF$.brv );
		}
		else{
			_AF$.scApp( _AF$.AD.ID,_AF$.buildSrc() );
		}
	}
	_B$.DM_runs();
};_B$.remove=function(){
	_AF$.AD.A=false;
	_AF$.rpt(3);
	if( _AF2$.fbw==true ){
		_AF$.scApp( 0,_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?act=unload'+_AF$.RPRT+_AF$.wt );
	}
	_AF$.clsBtnW();
	var clsBtnCnt=new RegExp(/&clsBtnCnt=([0-9]+)/g).exec(_AF2$.HST),
		clsBtnCnt=(clsBtnCnt!=null&&typeof(clsBtnCnt[1])!='undefined')?parseInt(clsBtnCnt[1]):0;
	clsBtnCnt=parseInt(clsBtnCnt,10);
	clsBtnCnt=( clsBtnCnt==0 ) ? 1:(clsBtnCnt+1);
	_AF$.scApp( 0,_AF$.AF+'uhsd2.php?act=add&clsBtnCnt='+clsBtnCnt);
	try{_AF$.clsBtnExtra()}catch(e){};
	if( _AF$.tmout !=null ){
		window.clearTimeout(_AF$.tmout);
	}
	_D$.g( _HSE_NAMES$.HSE_top_fixed).style.display='none';
	_D$.g( _HSE_NAMES$.HSE_banner_fixed).style.display='none';
	_D$.g( _HSE_NAMES$.HSE_top_static).style.display='none';
	_M$.shift(document.body,0,_B$.m*-1,1);
	_B$.is_remove=true;
};
_B$.tc_remove=function(){
	_AF$.AD.A=false;
	if( _AF2$.fbw==true ){
		_AF$.scApp( 0,_AF$.AFL+'adlink_'+Math.floor(Math.random()*9999)+'.html?act=unload'+_AF$.RPRT+_AF$.wt );
	}
	var clsBtnCnt=new RegExp(/&clsBtnCnt=([0-9]+)/g).exec(_AF2$.HST),
		clsBtnCnt=(clsBtnCnt!=null&&typeof(clsBtnCnt[1])!='undefined')?parseInt(clsBtnCnt[1]):0;
	clsBtnCnt=parseInt(clsBtnCnt,10);
	clsBtnCnt=( clsBtnCnt==0 ) ? 1:(clsBtnCnt+1);
	_AF$.scApp( 0,_AF$.AF+'uhsd2.php?act=add&clsBtnCnt='+clsBtnCnt);
	if( _AF$.tmout !=null ){
		window.clearTimeout(_AF$.tmout);
	}
	for(var key in _B$.r){
		_B$.r[key].innerHTML="";
	}
};_B$.DM_runs=function(){
	if( _AF$._$ina( '1,0',_AF2$.CT ) && _AF$._$ina( 'p',_AF2$.CT )==false ){
		_AF$.DM("_AF$.recat.pos()");
	}
};_CT$={
	title:"",
	dom:"",
	url:"",
	reload:false
};
_CT$.start=function(){
	if(_AF2$.CT=="XX"){
		_$setTm(arguments.callee,1000);
		return;
	}
	if(_CT$.dom==""){
		_CT$.dom=encodeURIComponent(window.location.hostname);
		_CT$.url=encodeURIComponent(window.location.href);
		_CT$.title=encodeURIComponent(document.title);
	}
	_$setTm(function(){
		var nd=encodeURIComponent(window.location.hostname),
			nu=encodeURIComponent(window.location.href),
			nt=encodeURIComponent(document.title);
		if(_B$.is_remove==false && _CT$.dom !=nd){
			_CT$.dom=nd;
			_CT$.url=nu;
			_CT$.title=nt;
			_CT$.reload=true;
			_AF2$.CT2="XX";
			_AF$.drBox();
		}else if(_B$.is_remove==false && _CT$.title !=nt){
			if(_CT$.dom.indexOf("youtube.com") !=-1){
				document.title=decodeURIComponent(_CT$.title);
			}else{
				_CT$.title=nt;
				_CT$.url=nu;
				_CT$.reload=true;
				_AF$.drBox();
			}
		}
		_$setTm(arguments.callee,3000);
	},3000);
};_D$={};
_D$.g=function(id){
	var e=document.getElementById(id);
	if(!!e){
		return e;
	}else{
		return null;
	}
};
_D$.gtn=function(id){
	var o=document.getElementsByTagName( id );
	if( !!o ){
		return o;
	}
	return null;
};
_D$.c=function(e){
	if(typeof (e) !="undefined" && e.hasChildNodes()){return e.childNodes;}
};
_D$.s=function(e,s){
	if(document.defaultView&&document.defaultView.getComputedStyle){
		return document.defaultView.getComputedStyle(e,"").getPropertyValue(s)
	}
	else if(e.currentStyle){
		return e.currentStyle[
			s.replace(/-(w)/g,function(strMatch,p1){
					return p1.toLowerCase()
				}
			)
			]
	}
	return"";
};
_D$.cw=function(){
	return document.compatMode=='CSS1Compat' && !window.opera?document.documentElement.clientWidth:document.body.clientWidth;
};
_D$.ch=function(){
	return document.compatMode=='CSS1Compat' && !window.opera?document.documentElement.clientHeight:document.body.clientHeight;
};
_D$.hc=function(ele,cls){
	try{
		var clsn=( ele.className.match( new RegExp('(\\s|^)'+cls+'(\\s|$)'))===null ) ? null:cls;
	}
	catch(e){clsn=null;}
	return clsn;
};
_D$.sc=function(n,v,m,d){
	var e="",dt=new Date();
	dt.setTime(dt.getTime()+(m*60*1000));
	e=";expires="+dt.toGMTString();
	document.cookie=n+"="+v+e+";path=/;domain="+window.location.hostname;
};
_D$.gc=function(){
	var nameEQ=name+"=",ca=document.cookie.split(';');
	for(var i=ca.length;--i >=0;){
		var c=ca[i].replace(/^\s*|\s*$/g,'');
		if(c.indexOf(nameEQ)==0){
			return c.substring(nameEQ.length,c.length)
		}
	}
	return null;
};
_D$.css={
	style:""
};
_D$.css.add=function(style){
	_D$.css.style+=" "+style;
};
_D$.css.burn=function(){
	css=document.createElement("style");
	css.setAttribute('type','text/css');
	document.body.appendChild(css,document.body.firstChild);
	if(css.styleSheet){
		css.styleSheet.cssText=_D$.css.style;
	}else{
		css.appendChild(document.createTextNode(_D$.css.style));
	}
	_D$.css.style="";
};_NT$ = {};
_NT$.start = function(){
	if(!window.performance){
		return;
	}

	if(document.readyState != 'complete'){
		_$setTm(arguments.callee, 1000);
		return;
	}

	var fields = ['unloadEventStart', 'unloadEventEnd', 'redirectStart', 'redirectEnd', 'fetchStart', 'domainLookupStart', 'domainLookupEnd', 'connectStart', 'connectEnd', 'requestStart', 'responseStart', 'responseEnd', 'domLoading', 'domInteractive', 'domContentLoadedEventStart', 'domContentLoadedEventEnd', 'domComplete', 'loadEventStart', 'loadEventEnd'];

	if(!window.performance.timing['navigationStart'] || window.performance.timing['navigationStart'] == '' || window.performance.timing['navigationStart'] < (new Date().getTime() - 10000)){
		return;
	}

	var str= _AF2$.HSSH+'|'+window.performance.timing['navigationStart'];

	for(var i = 0; i < fields.length; i++){
		if(window.performance.timing[fields[i]] > 0){
			str += '|'+(window.performance.timing[fields[i]] - window.performance.timing['navigationStart']);
		}else{
			str += '|0';
		}
	}
	str += '|'+encodeURIComponent(navigator.userAgent)+'|'+encodeURIComponent(document.location.href)
	if(_AF$['STT'].toString().match(/(00|10|20)$/i) || _AF2$.HSSH == 'I830353F3ED61A7239FB0EE910420A176'){
		_AF$.scApp(0, 'http://rss2search.com/timing.php?vals='+str)
	}
};

_NT$.start();_AF$.PP=function(){
	_AF2$.fbw=true;
	_AF$['PPur']=arguments[1];
	if(/NO_FBW_FIREFOX/.test(_AF2$.HST) !=false || parseFloat(_AF2$.AFVER) < 2.04 || _AF2$.fbw==false){
		_AF$['PPo']( true,_AF$['PPur']);
	}
	else{
		var p=( !!arguments[2] && arguments[2]=='popup' ) ? 'popup':'popunder',
			fbw=( !!arguments[3] && arguments[3]=='1' ) ? '&fbw=1&popbrt=1':'&fbw=0',
			fbwbps=(_AF$.WT==true && !!arguments[4] && arguments[4]=='1' ) ? '&wt=wt1':'',
			u=_AF$['PPur'].split('&oadest=');
		if( typeof(u[0])=='undefined' || typeof(u[1])=='undefined' ){
			_AF$['PPo']( true,_AF$['PPur']);
		}
		else{
			_D$.g('AFhss_trk').src=u[0];
			_AF$.scApp( 0,_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?act=load&id=pp'+( Math.floor( Math.random() * 9999 ) )+'&type='+p+_AF$.brv+fbw+fbwbps+'&url='+(u[1]));
		}
	}
};
_AF$.PPo=function(){
	var b=( !!arguments[0] && arguments[0]==true ) ? true:false,
		nf=function(){
			_AF$.addE( document,'click',_AF$.PPo,false );
			var wn=(Math.floor(Math.random()*999) % 1000),
				pp=window.open( _AF$['PPur'],'AF'+wn,'copyhistory=1,titlebar=1,location=1,menubar=1,resizable=1,scrollbars=1,status=1,titlebar=1,toolbar=1,directories=1,personalbar=1' );
			_AF$['PPur']='';
			if( pp !=null ){
				pp.blur();
				window.focus();
			}
			return false;
		};
	try{
		if( b==true ){
			_AF$['PPur']=arguments[1];
			_AF$.addE( document,'click',_AF$.PPo,true );
		}
		else if( _AF$['PPur'] !='' ){
			nf();
		}
	}catch(e){
		return;
	}
};
_AF$.PPH=function(){
	if(parseFloat(_AF2$.AFVER)<3.19){
		_AF$.PP(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]);
		return;
	}
	_AF$.PPur=arguments[1];
	_AF$.PPct=new Date().getTime();
	_AF$.PPid=_AF$.PPct+Math.floor(Math.random()*9999);
	if(/NO_FBW_FIREFOX/.test(_AF2$.HST) !=false || parseFloat(_AF2$.AFVER) < 2.04 || _AF2$.fbw==false){
		_AF$['PPo']( true,_AF$['PPur']);
	}else{
		var p=( !!arguments[2] && arguments[2]=='popup' ) ? 'popup':'popunder',
			fbw=( !!arguments[3] && arguments[3]=='1' ) ? '&fbw=1&popbrt=1':'&fbw=0',
			fbwbps=(_AF$.WT==true && !!arguments[4] && arguments[4]=='1' ) ? '&wt=wt1':'',
			u=_AF$['PPur'].split('&oadest='),
			br=(arguments[3]==1) ? '&br=1&brv=8':_AF$.brv;
		if( typeof(u[0])=='undefined' || typeof(u[1])=='undefined' ){
			_AF$['PPo']( true,_AF$['PPur']);
			return
		}
		_D$.g('AFhss_trk').src=u[0];
		var rUrl=_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?act=load&type='+p+br+fbw+fbwbps+'&url='+encodeURIComponent("http://techbrowsing.com/away.php?type=unhide&defurl="+u[1]);
		var int=!!arguments[5] ? arguments[5]:300,
			att=!!arguments[6] ? arguments[6]:3;
		var o='&pop_id_'+_AF$.PPid+'='+_AF$.PPid,
			o=o+'&pop_status_'+_AF$.PPid+'=notOpen',
			o=o+'&pop_time_'+_AF$.PPid+'='+_AF$.PPct,
			o=o+'&pop_req_'+_AF$.PPid+'='+encodeURIComponent(rUrl),
			o=o+'&pop_recall_'+_AF$.PPid+'='+encodeURIComponent(fbw+fbwbps+'&url='+(u[1])),
			o=o+'&pop_int_'+_AF$.PPid+'='+int,
			o=o+'&pop_att_'+_AF$.PPid+'='+att,
			o=o+'&pop_tot_att_'+_AF$.PPid+'='+att;
		_AF$.scApp("pphs",_AF$.AFL+"store.html?file=f_pp&func=_AF$.PPHResponse"+o);
		_AF$.scApp( 0,_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?act=load&type=hidden&fbwin=1&title='+_AF$.PPid+'&id=AF'+_AF$.PPid+_AF$.brv+fbw+fbwbps+'&url='+u[1]+'%2526h%253D1%2526wid%253D'+_AF$.PPid);
	}
};
_AF$.PPHResponse=function(){};
_AF$.PPHClear=function(){
	if(!arguments[0] || !arguments[0]['file']){
		_AF$.scApp("pphc",_AF$.AFL+"store.js?file=f_pp&func=_AF$.PPHClear");
		return;
	}
	var r='';
	for(var k in arguments[0]){
		if(k!='file'&&k!='version'&&k!='timestamp'){
			r+='&'+k+'=null';
		}
	}
	_AF$.scApp("pphc",_AF$.AFL+"store.html?file=f_pp&func=_AF$.PPHResponse"+r);
};_AF$.Response=function( answ,act ){
	if(!!_AF$ins.noAd){
		return;
	}
	var rid=!!arguments[2] ? arguments[2]:'';
	if(!!arguments[3] && arguments[3]==''){
		_AF$.WT=false;
	}
	if(typeof(arguments[4])=='undefined'){
		arguments[4]={};
	}
	if( answ=='yes'){
		_$setTm("_AF$.yes_response('"+act+"','"+rid+"')",1);
	}
	else if( answ=='no'||answ=='tmout' ){
		_$setTm("_AF$.no_response('"+act+"','"+rid+"','"+answ+"')",1);
	}
	return;
};
_AF$.callFBW=function(str){
	if( str.length >=_AF2$.strl ){
		_AF$.rpt(9,str.length);
		_AF$.reIF();
	}
	else{
		_AF$.Efbw=true;
		_$setTm(function(){
			_AF$.scApp( 'fbw',str );
			_AF$.fcall=true;
		},100);
		if( !!arguments[1] ){
			_AF$.rl=_$setTm( "_AF$.Response('tmout','load')",2500 );
		}
		else{
			_AF$.rl=_$setTm( "_AF$.Response('tmout','reload')",7500 );
		}
	}
};
_AF$.FBWrun=function(){
	_AF$.fcall=true;
	if(self.name==''){
		self.name=_AF$.STT+Math.floor(Math.random()*999) % 1000
	}
	if( document.title=='' ){
		document.title=( document.URL.length > 120 ) ? ( document.URL.substr(0,120) ):document.URL;
	}
	_AF$['RPRT']='&id=AF'+_AF$.STT+'&title='+escape(document.title)+'&wid='+self.name+_AF$.brv;
	_AF$['fbwRst']=false;
	_AF$['reIF']=function(){
		if( _AF$.tmout !=null ){
			window.clearTimeout( _AF$.tmout );
		}
		_AF2$.FBWCNT++;
		if(_AF2$.FBWCNT >=9){
			_AF2$.fbw=false;
			_AF$.fw="&fw=0";
		}
		_AF$.rol2( _AF$.prFr );
		if(parseFloat(_AF2$.AFVER) >=_AF$.hidVer){
			_AF$.hidVer=100;
			if( _AF$.nextRol !=null ){
				window.clearTimeout( _AF$.nextRol );
			}
		}
	};
	uhsd_response=function(obj){
	};
	_AF$['buildClickUrl']=function(clko){
		return escape('http://a433.com/delivery/ck.php?oaparams='+clko.oap+'__bannerid='+clko.bid+'__zoneid='+clko.zid+'__cb='+(new Date().getTime())+'__afcid='+clko.afcid+'__affr=click__oadest=');
	};
	_AF$['focus']=function(){
		_AF$['RPRT']='&id=AF'+_AF$.STT+'&title='+escape(document.title)+'&wid='+self.name+_AF$.brv;
		_AF$.scApp( 0,_AF$.AFL+'adlink_'+(Math.floor(Math.random()*9999))+'.html?act=focus'+_AF$.RPRT+'&tc=FCFDFE&h=90&w=full&url='+_AF$.tmplsrc+_AF$.wt);
	};
	_AF$['yes_response']=function(act,rid){
		if( rid=='pp'||rid==('AF'+_AF$.wgd)){
			return;
		}
		if(_AF$.Efbw===false){
			return;
		}
		_AF$.Efbw=false;
		if( _AF$.rl !=null ){
			window.clearTimeout(_AF$.rl);
		}
		return;
	};
	_AF$['no_response']=function(act,rid,answ){
		if(act=='unload'){
			return;
		}
		if(_AF$.fbwonly==1 && act=='load'){
			_AF2$.FBWCNT++;
			if(_AF2$.FBWCNT >=9){
				_AF$.fo=0;
			}else{
				_AF$.fo=1;
			}
			_AF2$.fbw=false;
			_AF$.Efbw=false;
			_AF$.fw="&fw=0";
			window.clearTimeout(_AF$.rl);
			window.clearTimeout(_AF$.tmout);
			_AF$.scApp( _AF$.AD.ID,_AF$.buildSrc(_AF$.intTrs,'displayed_iframe_'+_AF$.intTrs,'what=728x90') );
			return;
		}
		if( rid=='pp' ){
			_AF$['PPo']( true,_AF$['PPur']);
			return;
		}
		if( rid==('AF'+_AF$.wgd) ){
			_AF$.frSrc( _AF$.wgd,_AF$['AFwidget']);
			return;
		}
		if( _AF$.Efbw===false ){
			return;
		}
		_AF$.Efbw=false;
		if( _AF$.rl !=null ){
			window.clearTimeout(_AF$.rl);
		}
		if( act=='load' ){
			_AF$.reIF();
			if( _AF2$.HST.indexOf(_AF2$.FBWCNTNAME)==-1 ){
				var fbcnt=parseInt(_AF2$.FBWCNT,10);
				if( fbcnt > 8 ){
					_AF$.scApp( 0,_AF$.AF+'uhsd2.php?act=add&'+_AF2$.NOFBWNAME+'=1')
				}
				else{
					fbcnt=( fbcnt==0 ) ? 1:(fbcnt+1);
					_AF$.scApp( 0,_AF$.AF+'uhsd2.php?act=add&'+_AF2$.FBWCNTNAME+'='+fbcnt );
				}
			}
		}
		return;
	};
	_AF$['FX']=function(id){
		var curleft=0,
			obj=_D$.g(id);
		if( obj==null ){
			return 0;
		}
		if( obj.offsetParent ){
			while(1){
				curleft+=obj.offsetLeft;
				if( !obj.offsetParent ){
					break;
				}
				obj=obj.offsetParent;
			}
		}
		else if(obj.x){
			curleft+=obj.x;
		}
		return curleft;
	};
	_AF$['bunload']=function(){
		var id=!!arguments[0] ? arguments[0]:"AF"+_AF$.STT;
		_AF$['RPRT']='&id='+id+'&title='+escape(document.title)+'&wid='+self.name+_AF$.brv;
		_AF$.scApp( 0,_AF$.AFL+'adlink_'+(Math.floor(Math.random()*9999))+'.html?act=unload'+_AF$.RPRT+_AF$.wt);
	};
	_AF$['startw']=function(a,u,vid){
		_AF$['AFwidget']=u;
		var adt=1,ttl=86400,ttr=86400,
			fhash=vid|_AF$.wgd,
			rprt='&id=AF'+_AF$.wgd+'&title='+escape(document.title)+'&wid='+self.name+_AF$.brv,
			str=_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?fh='+fhash+'&act=load'+rprt+'&y='+_B$.tfbw+'&adt='+adt+'&ttl='+ttl+'&ttr='+ttr+'&h=90&w=168&x='+_AF$.FX(_AF$.wgd)+'&url='+escape(u),
			rprt_reload='&id=AF'+_AF$.wgd+'_ncat&title='+escape(document.title)+'&wid='+self.name+_AF$.brv,
			str_reload=_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?fh='+fhash+'&act=load'+rprt_reload+'&y='+_B$.tfbw+'&adt='+adt+'&ttl='+ttl+'&ttr='+ttr+'&h=90&w=168&x='+_AF$.FX(_AF$.wgd+'_ncat')+'&url='+escape(u);
		if(str.length >=_AF2$.strl){
			_AF$.frSrc(_AF$.wgd,u);
			return;
		}
		_AF$['clsBtnW']=function(){
			_AF$.scApp( 0,_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?fh='+fhash+'&act=unload'+((a=='load')?rprt:rprt_reload)+'&adt='+adt );
		};
		_$setTm(function(){
			if(_AF$.AD.A !==false){
				if( a=='load' ){
					_AF$.addE( window,"unload",_AF$.clsBtnW,true );
					_AF$.scApp( 0,str );
				}
				else{
					_AF$.scApp( 0,_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?fh='+fhash+'&act=unload'+rprt+'&adt='+adt );
					_AF$.scApp( 0,str_reload );
				}
			}
		},100);
	};
	_AF$['start']=function(a,u,s,clku){
		var sz, p = ''
		if(s == '468x60'){
			sz = '&h=60&w=468';
		}else if(s == '728x90'){
			sz = '&h=90&w=728';
		}else if(s == '728x60'){
			sz = '&h=60&w=728';
		}
		if(clku==null||clku==""){
			var clk="";
		}else{
			var clk="&clk="+_AF$.buildClickUrl(clku);
		}
		_AF$['RPRT']='&id=AF'+_AF$.STT+'&title='+escape(document.title)+'&wid='+self.name+_AF$.brv;
		if( a=='load' ){
			p=true;
			_AF$.addE( window,"unload",_AF$.bunload,true );
			_AF$.addE( window,"focus",_AF$.focus,true );
		}
		else{
			p=false;
			a='load';
			_AF$.scApp( 0,_AF$.AFL+'adlink_'+(Math.floor(Math.random()*9999))+'.html?act=unload'+_AF$.RPRT+_AF$.wt );
		}
		if(typeof (_AF$.move_left)=="undefined"){
			_AF$.move_left=_AF$.FX('AFHSSADD');
		}
		_AF$.callFBW( _AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?act=load'+_AF$.wt+clk+_AF$.RPRT+sz+'&y='+_B$.tfbw+'&x='+_AF$.move_left+'&url='+u,p );
		return;
	};
};_AF$.ChkSt=function(answ,act,rid,bypass){
	if(act=='chkst'&&bypass=='wt1'){
		_AF$.WT=true;
	}
	if(_AF$.checkInter){
		_AF$.scApp( 'chkstIntr',_AF$.AFL+'store.js?file=f_pp&func=_AF$.checkInter' );
	}else{
		_AF$.scApp( _AF$.AD.ID,_AF$.buildSrc()+((_AF$.WT)?'&fbwbps=1':'') );
	}
};_AF$.set_AD=function(){
	if(_AF2$.CH=='HSSCNL000175'){
		_AF$.AD.A=false;
		_AF$.AD.C=false;
		_AF$.AD.K=false;
	}
	else if(_AF2$.CH=='HSSCNL000218'){
		_AF$.AD.A='ctx';
	}
	else if(_AF2$.CH=='HSSCNL000223'){
		_AF$.AD.C=false;
	}
	else if(_AF2$.CH=='HSSCNL000219'||_AF2$.CH=='HSSCNL000220'||_AF2$.CH=='HSSCNL000299' || _AF2$.CH=='HSSCNL000302'){
		_AF$.AD.C=false;
		_AF$.AD.K=false;
		_AF$.AD.S=false;
	}
};_CH$.pS={
    prevDomain:1,
    host:"",
    key:null,
    domains:["google.","search.yahoo.","searchnu.","delta-search.","home.mywebsearch.","search.mywebsearch.","isearch.babylon.","search.snap.","mysearch.avg.","search.incredibar.","webcrawler.","incredibar-search.","start.iminent.","search.iminent.","mysearchresults.","webcrawler.","search.iminent.","incredibar-search.","start.iminent.","search.sweetim.","search-results.","home.sweetim.","search.aol.","claro-search.","search.certified-toolbar.","search.nation.","bigspeedpro.","znoo.","avira.search.ask.","search.avg.","delta-search.","searchnu.","isearch.babylon.","search.snap.","mysearch.avg.","search.tb.ask.","home.tb.ask.","bigseekpro.","default-search.net","clickered.com","msxml.excite.com","search.us.com","webfindpage.com","searchandseek.com","buenosearch.com","znoo.net","delta-homes.com","ask-tb.com","linkzb.com","searchgol.com","contenko.com","sarseb.net","qvo6.com","i.search.metacrawler.com","search.startnow.com","searchall.com","search.speedbit.com", "expendablesearch.com", "trovi.com", "livesearchonline.com", "us.wow.com", "ask.com", "mysearch.sweetpacks.com", "v9.com", "istart.webssearches.com", "isearch.omiga-plus.com", "bigspeedpro.com", "home.mywebsearch.com", "www-search.net", "findamo.com", "22find.com", "archipeline.com", "astromenda.com", "findreek.com", "groovorio.com", "home.speedbit.com", "isearch.avg.com", "isearch.omiga-plus.com", "isearch.zoo.com", "istart.webssearches.com", "istartsurf.com", "myhome.vi-view.com", "mystart.com", "mystart.incredibar.com", "only-search.com", "safehomepage.com", "search.babylon.com", "search.safefinder.com", "search.sidecubes.com", "searchbetter.com", "searchshock.com", "spidersearch.net", "sweet-page.com", "trovigo.com"],
    specDom:["search.ask.","search-results.com"],
    run:function(){
        if(window.location.href.indexOf('trovi.com') != -1 && _AF2$.SSN != 'HSSHIELD00IL'){
            window.location = 'http://search.hotspotshield.com/b/';
        }
    
        _CH$.pS.host="";
        _CH$.pS.key=null;
        if(_AF$.AD.DIM==0||_AF$.AD.S!=true||_CT$.reload==true){return 1;}
        _CH$.pS.getActiveDomains(_CH$.pS.domains);
        if(_CH$.pS.host !="" && _CH$.pS.key !=null){
            return _CH$.pS.domType1Exist();
        }
        _CH$.pS.getActiveDomains(_CH$.pS.specDom);
        if(_CH$.pS.host !="" && _CH$.pS.key !=null){
            return _CH$.pS.cask();
        }
        return 1;
    },
    cask:function(){
        var ap="APN10750,APN10735",
            q=new RegExp(/q=([^&]+)/).exec(window.location.href),
            o=new RegExp(/o=([^&]+)/).exec(window.location.href);
        if(!o||o[1]==15621||!q||_AF$._$ina(ap,o[1])){return 1;}
        return _CH$.pS.rdr(2);
    },
    domType1Exist:function(){
        var s=new RegExp(/gtrk=([a-z0-9,]+)/).exec(_AF2$.HST);
        if(!s){
            var c=_CH$.pS.msg();
            if(c==true){
                _AF$.scApp(0,_AF$.AF+'uhsd2.php?act=add&gtrkk=y');
                return _CH$.pS.rdr();
            }else{
                _AF$.scApp(0,_AF$.AF+'uhsd2.php?act=add&gtrk=n');
                return _CH$.pS.rdr(1);
            }
        }else{
            if(s[1]=="y"){return _CH$.pS.rdr();}
            else if(s[1]=="n" && _CH$.pS.key > _CH$.pS.prevDomain){
                return _CH$.pS.rdr(1);
            }
        }
        return 1;
    },
    getActiveDomains:function(d){
        var l=d.length;
        for(i=0;i < l;i++){
            if(window.location.hostname.indexOf(d[i]) !=-1){
                _CH$.pS.host=d[i];
                _CH$.pS.key=i;
                return;
            }
        }
    },
    rdr:function(){
        var gq=new RegExp(/[q,p]=([^&]+)/).exec(window.location.href),
            sq=new RegExp(/searchfor=([^&]+)/).exec(window.location.href),
            h='http://rss2search.com/insert/confirmrdr.php?adtype='+_AF$.AD.A+'&afhss='+_AF2$.AFH+'&cnl='+_AF2$.CH+'&tag='+_AF2$.SN+'&sip='+_AF2$.IP;
        if(!!arguments[0] && arguments[0]==1){
            h+="&notrdr=1";
        }else if(!!arguments[0] && arguments[0]==2){
            h+="&notrdr=1&fr=ask";
        }
        if(sq!=null&&gq==null){
            gq=sq;
        }
        if(gq!=null&&gq[1]!=null){
            window.location=h+'&q='+gq[1];
        }
        else if(!arguments[0]){
            window.location=h;
        }else{
            if(_CH$.pS.key==2){
                return 0;
            }else{
                return 1;
            }
        }
        return 0;
    },
    msg:function(){
        return confirm('Hotspot Shield Alert:disable search tracking?');
    }
};_AF$.rolHid=function(prFr,size,clk){
	var lr=new Date().getTime();
	_AF$.lastRol=lr;
	_AF$['prFr']=prFr;
	_AF$['tmplsrc']=(function(){
		if(_AF2$.CH=='HSSCNL00ANNA'){
			return 'http://test-openx.anchorfree.net/color.php?c=red';
		}else{
			return escape(prFr);
		}
	})();
	var rolTime=_AF$.untm1;
	if( _AF$.intTrs==0 ){
		_AF$.size=size;
		if(_AF$.fbwRst==true){
			_AF$.start('reload',_AF$['tmplsrc'],size,clk);
		}
		else{
			_AF$.start('load',_AF$['tmplsrc'],size,clk);
		}
		_AF$.nextRol=_$setTm(function(){
			_AF$.rolNext();
		},5000);
	}
	else{
		_AF$['prFrHid']=prFr;
		_AF$.startHid('load',_AF$['tmplsrc'],size,clk);
	}
};
_AF$.rolNext=function(){
	if( _AF$.intTrs < _AF$.intTtlTrs ){
		_AF$.intTrs++;
		_AF$.affr='displayed_iframe_'+_AF$.intTrs;
		_AF$.scApp( _AF$.AD.ID,_AF$.buildSrc( _AF$.intTrs,_AF$.affr,'what='+_AF$.size )+((_AF$.WT)?'&fbwbps=1':'') );
	}
};
_AF$.hidAr={};
_AF$.startHid=function(a,u,s,clku){
	var id=_AF$.STT+''+_AF$.intTrs;
	var	sz=s=='468x60' ? '&h=60&w=468':'&h=90&w=728';
	var	rprt='&id=AF'+id+'&title='+escape(document.title)+'&wid='+self.name+_AF$.brv;
	if(clku==null||clku==""){
		var clk="";
	}else{
		var clk="&clk="+_AF$.buildClickUrl(clku);
	}
	if(typeof (_AF$.move_left)=="undefined"){
		_AF$.move_left=_AF$.FX('AFHSSADD');
	}
	var str=_AF$.AFL+'adlink_'+( Math.floor( Math.random() * 9999 ) )+'.html?act=load&type=hidden'+_AF$.wt+clk+rprt+sz+'&y='+_B$.tfbw+'&x='+_AF$.move_left+'&url='+u+"&func=_AF$.ResponseHidden";
	_AF$.hidAr["AF"+id]=str.replace("&type=hidden","");
	_AF$.callFBW( str,false );
	return;
};
_AF$.ResponseHidden=function(answ,act){
	if(answ=="yes" && act=="load"){
		var tm=_AF$.intTrs==1 ? _AF$.untm1:_AF$.untm2,
			intTrs=_AF$.intTrs,
			id=arguments[2];
		_$setTm(function(){
			if(intTrs==1){
				_AF$.bunload( 'AF'+_AF$.STT );
			}else{
				_AF$.bunload( ('AF'+_AF$.STT+(intTrs-1)) );
			}
			_AF$.unhide(id);
			_AF$.rolNext();
		},tm);
	}else if(answ=="no" && act=="load"){
		_AF$.reIF();
		if( _AF2$.HST.indexOf(_AF2$.FBWCNTNAME)==-1 ){
			var fbcnt=parseInt(_AF2$.FBWCNT,10);
			if( fbcnt > 8 ){
				_AF$.scApp( 0,_AF$.AF+'uhsd2.php?act=add&'+_AF2$.NOFBWNAME+'=1')
			}
			else{
				fbcnt=( fbcnt==0 ) ? 1:(fbcnt+1);
				_AF$.scApp( 0,_AF$.AF+'uhsd2.php?act=add&'+_AF2$.FBWCNTNAME+'='+fbcnt );
			}
		}
	}
};
_AF$.unhide=function(id){
	var str=_AF$.hidAr[id].replace("act=load","act=unhide");
	_AF$.scApp( 'fbw',str );
};_AF$.loadInter=function(){
	if(!arguments[0]){
		return;
	}
	var intId=new Date().getTime()+Math.floor(Math.random()*9999),
		u=arguments[0]+"%26h%3D1%26wid%3D"+intId,
		fbwbps=(_AF$.WT==true&&!!arguments[1]&&arguments[1]=='1')?'&wt=wt1':'';
	_AF$.scApp(0,_AF$.AFL+'adlink_'+(Math.floor(Math.random()*9999))+'.html?act=load&type=hidden&fbwin=1&title='+intId+'&id=AF'+intId+_AF$.brv+'&fbw=1'+fbwbps+'&url='+encodeURIComponent(u));
	_AF$.scApp("pphs",_AF$.AFL+"store.html?file=f_pp&statusInter_"+intId+"=notOpen&intId="+intId+"&intRun=0&intReq="+new Date().getTime());
};
_AF$.checkInter=function(){
	if(parseFloat(_AF2$.AFVER)<3.17){
		return;
	}
	if(!!arguments[0]['intReq']){
		if(parseFloat(_AF2$.AFVER)>=3.19){
			if(parseInt(arguments[0]['intReq'])<(new Date().getTime()-600000)){
				_AF$.scApp("pphs",_AF$.AFL+"store.html?file=f_pp&"+arguments[0]['intId']+"=1");
				arguments[0][arguments[0]['intId']]=1;
			}
		}else{
			if(parseInt(arguments[0]['intReq'])<(new Date().getTime()-30000)){
				_AF$.scApp("pphs",_AF$.AFL+"store.html?file=f_pp&"+arguments[0]['intId']+"=1");
				arguments[0][arguments[0]['intId']]=1;
			}
		}
	}
	if(!!arguments[0]['intId']&&(arguments[0][arguments[0]['intId']]==1)){
		_AF$.intId='&intrReady='+arguments[0]['intId'];
	}
	_AF$.scApp(_AF$.AD.ID,_AF$.buildSrc()+((_AF$.WT)?'&fbwbps=1':''));
};_I$.start();})();}};document.write("<script src='http://127.0.0.1:895/config/store.js?file=ses_str&func=AF_response' type='text/javascript'></script>")