AF_response({
	"file": "ses_str",
	"version": "3.42", 
	"timestamp": "1417102323",
	"AW_BAN": "1",
	"AW_BAN_TILL": "1417183984000",
	"timestamp": "1417105389475"})
